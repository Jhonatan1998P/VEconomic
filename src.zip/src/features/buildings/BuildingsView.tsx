// Este archivo ya no es utilizado como una ruta principal de navegación.
// Su funcionalidad ha sido integrada directamente en el menú de navegación principal.